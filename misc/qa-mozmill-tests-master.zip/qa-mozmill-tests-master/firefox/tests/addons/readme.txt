# Add-on Tests #

In addition to using Mozmill to test the application itself, it is also possible
to test any kind of add-on. Creating a test for an add-on is not much different
from creating Mozmill tests for Firefox itself.

For more information on Addo-ns Tests visit:
https://wiki.mozilla.org/QA/Mozmill_Test_Automation/Addon_Tests
