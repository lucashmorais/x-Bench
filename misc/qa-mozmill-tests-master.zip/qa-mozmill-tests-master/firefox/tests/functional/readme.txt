# Firefox Non-Restart Tests #

This location holds the Mozmill tests for Firefox.

For more information on running the normal Firefox tests visit:
https://developer.mozilla.org/en/Mozmill_Tests#Run_normal_Mozmill_tests

# Firefox Restart Tests #

Also contained in this location is the restartTests folder, which must be run
using the command line version of Mozmill, using the mozmill-restart command.
This allows the test to restart the browser, as is needed when installing
extensions, for example.

For more information on running the Firefox restart tests visit:
https://developer.mozilla.org/en/Mozmill_Tests#Run_Mozmill_restart_tests
