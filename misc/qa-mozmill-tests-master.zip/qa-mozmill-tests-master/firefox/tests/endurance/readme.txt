# Firefox Endurance Tests #

This location holds the Mozmill endurance tests for Firefox.

For more information on the endurance tests visit:
https://wiki.mozilla.org/QA/Mozmill_Test_Automation/Endurance_Tests/Documentation
