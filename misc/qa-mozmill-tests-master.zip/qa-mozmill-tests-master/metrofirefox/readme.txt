# Mozmill Tests for Metro Mode #

Mozmill tests are written in JavaScript. They can be run using the Mozmill command
line client adding the --app=metrofirefox argument. Once you have Mozmill installed,
you can contribute by running the tests, raising any issues you find and
writing new tests!

See the 'Mozmill' page on MDN for instructions on installing and running
Mozmill Tests - https://developer.mozilla.org/en-US/docs/Mozmill

If you have questions, feel free to join us in #automation on irc.mozilla.org or
use our Mozmill developer mailing list:
http://groups.google.com/group/mozmill-dev
