# Templates #

To make it easier for you to create your first Mozmill tests, we have prepared a
couple of template files. They will help you get familiar with the license
block, needed test functions, shared modules, and the coding style to use when
writing tests.

For more assistance writing new tests visit:
https://developer.mozilla.org/en-US/docs/Mozmill_Tests
https://developer.mozilla.org/en-US/docs/Mozmill_Tests/Mozmill_Style_Guide
