var randomScalingFactor = function(){ return Math.round(Math.random()*1000)};
var pontuacao =  [randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor()]; // altere cada uma das pontuacoes aki
var total = randomScalingFactor(); // altera a pontuacao final aki
var processor="Intel Core i7 2370QM",memory="8(2x4)GB 1600GHz",hd="1TB(2x 500GB) 5400RPM",os="Ubuntu 14.04";


var barChartData = {
	labels : ["Compile","Encryption","Browse","Compress","HD","Video","Image"],
	datasets : [
		{
            label: "Score",
			fillColor : "rgba(220,220,220,0.5)",
			strokeColor : "rgba(220,220,220,0.8)",
			highlightFill: "rgba(220,220,220,0.75)",
			highlightStroke: "rgba(220,220,220,1)",
			data : pontuacao
		},
	]

}
window.onload = function(){
    document.getElementsByTagName("h2")[0].innerHTML = "Final Score: "+total;
	document.getElementById("processor").innerHTML = processor;
	document.getElementById("memory").innerHTML = memory;
	document.getElementById("hd").innerHTML = hd;
	document.getElementById("os").innerHTML = os;
	var ctx = document.getElementById("barra").getContext("2d");
	window.myBar = new Chart(ctx).Bar(barChartData, {
		responsive : true
	});
}
